let userInputEl = document.getElementById("user-input");
let userInputSelectEl = document.getElementById("user-input-select");
let userOutputEl = document.getElementById("user-output");
let userOutputSelectEl = document.getElementById("user-output-select");
let buttonEl = document.getElementById("button");


function degreeToFahrenheit(celsiusValue) {
    let resultDF = (celsiusValue * (9 / 5)) + 32;
    resultDF = resultDF.toFixed(2);
    return resultDF;
    //userOutputEl.value = resultDF;
}

function degreeToKelvin(celsiusValue) {
    let resultDK = parseInt(celsiusValue) + 273.15;
    resultDK = resultDK.toFixed(2);
    return resultDK;
    //userOutputEl.value = resultDK;
}

function FahrenheitToDegree(FahrenheitValue) {
    let resultFD = ((FahrenheitValue) - 32) * (5 / 9);
    resultFD = resultFD.toFixed(2);
    return resultFD;
}

function FahrenheitToKelvin(FahrenheitValue) {
    let resultFK = ((FahrenheitValue) - 32) * 5 / 9 + 273.15;
    resultFK = resultFK.toFixed(2);
    return resultFK;
}

function KelvinToFahrenheit(KelvinValue) {
    let resultKF = ((KelvinValue) - 273.15) * (9 / 5) + 32;
    resultKF = resultKF.toFixed(2);
    return resultKF;
}

function KelvinToDegree(KelvinValue) {
    let resultKD = (KelvinValue) - 273.15;
    resultKD = resultKD.toFixed(2);
    return resultKD;
}

buttonEl.addEventListener("click", function() {
    if (userInputSelectEl.value === "Degree") {
        if (userOutputSelectEl.value === "Degree") {
            userOutputEl.textContent = userInputEl.value;
            console.log("d-d");
        } else if (userOutputSelectEl.value === "Fahrenheit") {
            let input = userInputEl.value;
            let result = degreeToFahrenheit(input);
            userOutputEl.textContent = result;
            console.log("d-f");
        } else if (userOutputSelectEl.value === "Kelvin") {
            let input = userInputEl.value;
            let result = degreeToKelvin(input);
            userOutputEl.textContent = result;
            console.log("d-k");
        }


    } else if (userInputSelectEl.value === "Fahrenheit") {
        if (userOutputSelectEl.value === "Fahrenheit") {
            userOutputEl.textContent = userInputEl.value;
            console.log("f-f");
        } else if (userOutputSelectEl.value === "Degree") {
            let input = userInputEl.value;
            let result = FahrenheitToDegree(input);
            userOutputEl.textContent = result;
            console.log("f-d");
        } else if (userOutputSelectEl.value === "Kelvin") {
            let input = userInputEl.value;
            let result = FahrenheitToKelvin(input);
            userOutputEl.textContent = result;
            console.log("f-k");
        }

    } else if (userInputSelectEl.value === "Kelvin") {
        if (userOutputSelectEl.value === "Kelvin") {
            userOutputEl.textContent = userInputEl.value;
            console.log("k-k");
        } else if (userOutputSelectEl.value === "Degree") {
            let input = userInputEl.value;
            let result = KelvinToDegree(input);
            userOutputEl.textContent = result;
            console.log("k-d");
        } else if (userOutputSelectEl.value === "Fahrenheit") {
            let input = userInputEl.value;
            let result = KelvinToFahrenheit(input);
            userOutputEl.textContent = result;
            console.log("k-f");
        }
    }

})